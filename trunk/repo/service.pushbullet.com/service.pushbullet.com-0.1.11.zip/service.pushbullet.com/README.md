service.pushbullet.com
======================

Kodi (XBMC) service for receiving push notification via Pushbullet

Work in progress - currently unreleased.

Right now it allows pushing video links and having them play in XBMC.
